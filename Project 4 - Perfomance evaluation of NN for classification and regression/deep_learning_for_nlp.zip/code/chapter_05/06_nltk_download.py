import nltk
nltk.download()